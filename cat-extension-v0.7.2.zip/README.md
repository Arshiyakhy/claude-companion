# Cat side chat (v0.7.2)

A pixel cat that sits on your AI chat. Click it, and it swats its yarn ball, which rolls out into a small chat bar. Ask side questions about the chat without writing anything into it, then bring what you learned back, fork the chat, or hand its memory to a teammate.

Works on Claude, ChatGPT, Gemini and Grok. On any other site, click the extension's icon to wake the cat there.

## Install (Chrome, Edge, Brave, Opera, Arc)

1. Unzip this folder somewhere you'll keep it.
2. Open `chrome://extensions` (in Opera: `opera://extensions`) and turn on **Developer mode**.
3. Click **Load unpacked** and pick the folder.
4. Open claude.ai, chatgpt.com, gemini.google.com or grok.com. The cat appears in the bottom right corner.

## Using it

- **Click the cat** to open the bar, and click it again to close it (X and Escape close it too).
- **Highlight** something in the chat first, and the side question is about that part.
- **Type a question** and press Enter. Tab+Enter or Shift+Enter makes a new line.
- **Type /** to see the commands.
- **Move the cat** (with the bar open or closed): double-tap it, and it follows your pointer until you tap again to drop it. Escape puts it back where it was. You can also press and hold it for a moment, then drag. It remembers where you left it.

- **Size:** everything (cat, bar, text, panels) sizes itself to your monitor together. To change it, use the **− 100% +** control above the bar while it's open (it moves into the panel's top bar when a panel is open): steps of 10%, up to 150%. The cat and the bar always change by exactly the same amount. "−" stops where the text would get too small to read (around 80% on a 1080p screen, 100% on a small laptop). Click the percentage to go back to 100%. Your size is remembered. The cat stays sharp at any Windows display scaling and resizes if you drag the window to another monitor.

## Commands

| Command | What it does |
|---|---|
| /branch | Ask a side question about this chat. Just typing a question does the same. |
| Branch from here | The button under each side answer. Starts a new branch of that side chat from that point, as deep as you like, without changing the original. |
| /merge | Writes a short note of what you worked out in the side chat and puts it in the main chat's message box. You read it and press send yourself. |
| /tree | A map of everything that grew out of this chat: the main chat's messages as a line of dots, each side chat hanging off the message it came from (with its own branches), merged ones marked, plus the chat this one was forked from and the chats forked from it. Click a message to jump to it, a side chat to reopen it, or a fork to open that chat. |
| /fork | Starts a fresh chat that already knows everything from this one, using a memory pack. |
| /share | Makes a memory pack of this chat (project, decisions, key details, next steps) for a teammate. You can edit it first, and lines that look like passwords or keys are flagged. |
| /clone | Paste a teammate's pack to start a chat that's already caught up. Packs work across AIs: share from ChatGPT, clone into Claude. |
| /key | Saves your free Gemini key (see below). |

## Who answers the cat's questions

- **On Claude:** your own Claude account answers, in a hidden chat that's deleted when you close the side chat. It's free.
- **Everywhere else:** Google's Gemini answers, using a free API key. Get one at aistudio.google.com/apikey and paste it in when the cat asks (or with /key). The key stays in your browser. The free tier has limits, so if it says the limit is used up, wait a minute.

On sites other than Claude, /fork and /clone open a new chat with the pack already in the message box. Press send to start.

## The cat's faces

It's happy when the bar opens and thinking while an answer comes in. It gets star eyes when you merge, winks when you copy a pack, looks surprised on errors, and gets sleepy if nobody moves for a while. It also blinks, breathes, follows your pointer, and bats its ball now and then.

## Good to know

- The cat reads chats from each site's page, and on Claude from the same data the page loads. None of this is an official API, so a site redesign can break it. Each site's reading code is a few lines in `sites.js`, which makes fixes quick.
- Automating these sites may go against their terms, so use it for your own chats.

## Files

| File | What it does |
|---|---|
| manifest.json | Tells the browser what the extension is and where it runs |
| background.js | Talks to Gemini for the free key route, and wakes the cat when you click the icon |
| sites.js | The only part that knows each site: reads the chat, finds the message box |
| claude.js | Claude account access: reads the chat and asks in hidden chats |
| ai.js | Picks who answers (your Claude account or a Gemini key) |
| brain.js | What each command does, step by step |
| store.js | Saves side chats for /log |
| shell.js | Everything you see: the cat, bar, menu and panels |
| cat-roll.js | Draws the pixel cat, its faces and the yarn roll |
| logo-data.js | The cat's shape, traced from the logo |
| theme.js | Matches the site's light or dark colors |
| markdown.js | Shows answers with code blocks and lists |
