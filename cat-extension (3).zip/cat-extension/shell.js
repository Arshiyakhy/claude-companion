// SHELL: everything you see. The cat (drawn by cat-roll.js), the chat bar its
// yarn ball unrolls into, the / command menu, and the side chat panel.
// It all lives inside a Shadow DOM, a sealed box whose styles cannot leak into
// the Claude page and cannot be broken by it.
//
//   hover the cat  -> it swats its ball, the ball rolls left and unwinds into the bar
//   type /         -> the command menu pops up above the bar
//   branch (or just type a question) -> the side chat panel opens above the bar
//   share          -> writes a memory pack of this chat to send a teammate
//   clone          -> starts a new chat from a teammate's memory pack
//   X or Escape    -> the bar winds back up into the ball, home to the cat
//   hold the cat   -> pick it up and drop it anywhere; it remembers the spot
(function () {
  const CatExt = (window.CatExt = window.CatExt || {});
  if (document.getElementById("cat-ext-host")) return;

  const ICONS = {
    branch: '<circle cx="6" cy="5" r="2"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="8" r="2"/><path d="M6 7v10M18 10c0 4-6 3-11.2 7.4"/>',
    merge: '<circle cx="6" cy="5" r="2"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="19" r="2"/><path d="M6 7v10M6.8 6.7C9 12 12 17 16 18.6"/>',
    share: '<path d="M12 3v12M7.5 7.5L12 3l4.5 4.5"/><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/>',
    clone: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
  };
  const COMMANDS = [
    { name: "branch", hint: "Ask a side question about this chat", enabled: true },
    { name: "share", hint: "Make a memory pack of this chat for a teammate", enabled: true },
    { name: "clone", hint: "Start a chat from a teammate's memory pack", enabled: true },
    { name: "merge", hint: "Combine memory packs from teammates", enabled: false },
  ];
  const R = CatExt.roll;
  const BAR_H = R.BAR_H, CAT_W = R.CAT_W;
  const SIZE = { w: 440 + CAT_W, h: 340 }; // the width is set by layout() below

  // ---------- host and styles ----------
  const host = document.createElement("div");
  host.id = "cat-ext-host";
  host.style.cssText = `position:fixed;left:0;top:0;width:${SIZE.w}px;height:${SIZE.h}px;z-index:2147483647;pointer-events:none;`;
  const root = host.attachShadow({ mode: "open" });

  root.innerHTML = `
<style>
:host{all:initial}
*{box-sizing:border-box}
.wrap{position:relative;width:100%;height:100%;color:var(--c-ink);font-family:var(--c-font);font-size:14px;line-height:1.5}
svg.anim{position:absolute;inset:0;width:100%;height:100%;overflow:visible;pointer-events:none;z-index:2}
.cathit{position:absolute;right:0;bottom:0;width:${CAT_W + 50}px;height:96px;border:0;padding:0;background:transparent;border-radius:30px;cursor:pointer;pointer-events:auto;z-index:3;touch-action:none}
.wrap.dragging .cathit{cursor:grabbing}
/* cat on the left side of the screen: everything flips, the ball rolls right */
.wrap.mirror svg.anim{transform:scaleX(-1)}
.wrap.mirror .cathit{right:auto;left:0}
.wrap.mirror .composer{right:auto;left:${CAT_W}px}
.wrap.mirror .bar{flex-direction:row-reverse}
.wrap.mirror .closex{left:auto;right:-8px}
.wrap.mirror .menu{left:auto;right:8px}
/* cat near the top of the screen: the panel and menu open below the bar */
.wrap.below .composer{bottom:auto;top:calc(100% - ${BAR_H}px);flex-direction:column-reverse}
.wrap.below .menu{bottom:auto;top:calc(100% + 8px)}
button{font:inherit;color:inherit}
:focus-visible{outline:2px solid var(--c-ink);outline-offset:2px}

/* everything that opens sits in one column anchored to the bottom right */
.composer{position:absolute;right:${CAT_W}px;bottom:0;width:var(--bar-w,440px);display:none;flex-direction:column;gap:8px;align-items:stretch;z-index:1}
.wrap.open .composer{display:flex}
.wrap.open .composer{pointer-events:auto}

/* the bar, shaped like Claude's input */
.barwrap{filter:drop-shadow(0 8px 20px var(--c-shadow))}
.bar{position:relative;display:flex;align-items:flex-end;gap:6px;min-height:${BAR_H}px;padding:5px 6px;border-radius:28px;background:var(--c-bg);border:1px solid var(--c-border-strong)}
.ballbtn,.send{width:44px;height:44px;flex:none;border:0;border-radius:22px;display:flex;align-items:center;justify-content:center;cursor:pointer}
.ballbtn{background:transparent;color:var(--c-ink);border:1.5px solid var(--c-border-strong);font-size:18px;font-weight:600;line-height:1;opacity:var(--slash-o,1);transform:scale(var(--slash-s,1))}
.ballbtn:hover,.ballbtn[aria-expanded="true"]{background:var(--c-soft)}
.closex{opacity:var(--done,1)}
.send{background:var(--c-ink);color:var(--c-bg)}
.send:disabled{opacity:.35;cursor:default}
.in{flex:1;min-width:0;height:44px;max-height:150px;resize:none;border:0;background:transparent;color:var(--c-ink);font:inherit;font-size:15px;line-height:22px;padding:11px 4px;overflow-y:auto}
.in:focus{outline:none}
.in::placeholder{color:var(--c-muted)}
.closex{position:absolute;top:-12px;left:-8px;width:28px;height:28px;border-radius:14px;border:1px solid var(--c-border-strong);background:var(--c-bg);color:var(--c-ink);display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;box-shadow:0 2px 8px var(--c-shadow)}
.closex::before{content:"";position:absolute;inset:-8px}
.closex:hover{background:var(--c-soft)}

/* the / menu */
.menu{position:absolute;left:8px;bottom:calc(100% + 8px);width:300px;max-width:calc(100% - 16px);padding:6px;border-radius:16px;background:var(--c-bg);border:1px solid var(--c-border-strong);box-shadow:0 12px 32px var(--c-shadow);display:none;flex-direction:column;gap:2px}
.menu.show{display:flex}
.item{display:flex;align-items:center;gap:12px;min-height:44px;padding:6px 10px;border:0;border-radius:10px;background:transparent;text-align:left;cursor:pointer;width:100%}
.item svg{width:20px;height:20px;flex:none;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
.item .t{display:flex;flex-direction:column;min-width:0;flex:1}
.item .n{font-weight:600;font-size:14px}
.item .h{font-size:12px;color:var(--c-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.item .soon{font-size:11px;color:var(--c-muted);border:1px solid var(--c-border);border-radius:8px;padding:1px 6px}
.item.on{background:var(--c-soft)}
.item[aria-disabled="true"]{cursor:default}
.item[aria-disabled="true"] .n,.item[aria-disabled="true"] svg{opacity:.5}
.menu .empty{padding:10px;font-size:13px;color:var(--c-muted)}

/* the side chat panel, above the bar */
.panel{display:none;flex-direction:column;max-height:var(--panel-h,460px);border-radius:20px;background:var(--c-bg);border:1px solid var(--c-border-strong);box-shadow:0 12px 32px var(--c-shadow);overflow:hidden;
  transform-origin:50% 100%;animation:rise .28s cubic-bezier(.2,.8,.2,1)}
.panel.show{display:flex}
@keyframes rise{from{opacity:0;transform:translateY(12px) scale(.97)}to{opacity:1;transform:none}}
.head{display:flex;align-items:center;gap:10px;padding:8px 8px 8px 14px;border-bottom:1px solid var(--c-border);flex:none}
.head .chip{display:flex;align-items:center;gap:6px;font-weight:650}
.head .chip svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.head .sub{flex:1;min-width:0;font-size:12px;color:var(--c-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.endbtn{min-height:36px;padding:0 12px;border-radius:18px;border:1px solid var(--c-border-strong);background:transparent;cursor:pointer;font-size:13px}
.endbtn:hover{background:var(--c-soft)}
.body{overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:12px}
.quote{border-left:3px solid var(--c-border-strong);background:var(--c-mark);border-radius:6px;padding:6px 10px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12.5px;white-space:pre-wrap;max-height:110px;overflow:auto}
.label{font-size:12px;color:var(--c-muted);margin-bottom:-6px}
.note{font-size:12px;color:var(--c-muted)}
.you{align-self:flex-end;max-width:85%;background:var(--c-soft);border-radius:16px;padding:8px 12px;white-space:pre-wrap;overflow-wrap:anywhere}
.ans{overflow-wrap:anywhere}
.ans > :first-child{margin-top:0}.ans > :last-child{margin-bottom:0}
.ans p,.ans ul,.ans ol,.ans h4,.ans .code{margin:0 0 10px}
.ans ul,.ans ol{padding-left:20px}
.ans li{margin:2px 0}
.ans h4{font-size:14px;font-weight:650}
.ans a{color:inherit;text-decoration:underline}
.ans code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12.5px;background:var(--c-code);border:1px solid var(--c-border);border-radius:5px;padding:0 4px}
.ans .code{background:var(--c-code);border:1px solid var(--c-border);border-radius:10px;overflow:hidden}
.ans .code .lang{font-size:11px;color:var(--c-muted);padding:6px 10px 0}
.ans pre{margin:0;padding:8px 10px 10px;overflow-x:auto}
.ans pre code{background:none;border:0;padding:0;line-height:1.55}
.err{color:var(--c-err)}
.pack{width:100%;min-height:220px;max-height:300px;resize:vertical;border:1px solid var(--c-border-strong);border-radius:12px;padding:10px 12px;background:var(--c-code);color:var(--c-ink);font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12.5px;line-height:1.5}
.pack:focus-visible{outline:2px solid var(--c-ink);outline-offset:1px}
.warn{border:1px solid var(--c-err);border-radius:10px;padding:8px 10px;font-size:12.5px;color:var(--c-ink)}
.warn b{color:var(--c-err)}
.warn ul{margin:4px 0 0;padding-left:18px}
.actions{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.primary{min-height:44px;padding:0 18px;border-radius:22px;border:0;background:var(--c-ink);color:var(--c-bg);font-weight:600;cursor:pointer}
.primary:disabled{opacity:.4;cursor:default}
.dots{display:inline-flex;gap:4px;padding:6px 0}
.dots i{width:6px;height:6px;border-radius:3px;background:var(--c-muted);animation:b 1s infinite ease-in-out}
.dots i:nth-child(2){animation-delay:.15s}.dots i:nth-child(3){animation-delay:.3s}
@keyframes b{0%,80%,100%{opacity:.25}40%{opacity:1}}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
</style>
<div class="wrap">
  <svg class="anim" viewBox="0 0 ${SIZE.w} ${SIZE.h}" aria-hidden="true"></svg>
  <button type="button" class="cathit" aria-label="Cat helper, open the side chat bar"></button>
  <div class="composer">
    <section class="panel" role="region" aria-label="Side chat">
      <div class="head">
        <span class="chip"><svg viewBox="0 0 24 24" aria-hidden="true">${ICONS.branch}</svg><span class="chipname">branch</span></span>
        <span class="sub"></span>
        <button type="button" class="endbtn">End</button>
      </div>
      <div class="body" aria-live="polite"></div>
    </section>
    <div class="barwrap"><div class="bar">
      <div class="menu" role="listbox" aria-label="Commands"></div>
      <button type="button" class="ballbtn" aria-label="Commands" aria-haspopup="listbox" aria-expanded="false">/</button>
      <textarea class="in" rows="1" aria-label="Ask a side question, or type / for commands" placeholder="Ask a side question, or type / for commands"></textarea>
      <button type="button" class="send" aria-label="Send" disabled>
        <svg width="18" height="18" viewBox="0 0 16 16" aria-hidden="true"><path d="M8 13V3M3.5 7.5L8 3l4.5 4.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      <button type="button" class="closex" aria-label="Close and go back to the cat">
        <svg width="12" height="12" viewBox="0 0 16 16" aria-hidden="true"><path d="M3 3l10 10M13 3L3 13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
      </button>
    </div></div>
  </div>
  <div class="sr" aria-live="polite"></div>
</div>`;

  const $ = (s) => root.querySelector(s);
  const wrap = $(".wrap"), catHit = $(".cathit"), composer = $(".composer"), bar = $(".bar");
  const menu = $(".menu"), ballBtn = $(".ballbtn"), input = $(".in"), sendBtn = $(".send"), closeX = $(".closex");
  const panel = $(".panel"), body = $(".body"), sub = $(".sub"), endBtn = $(".endbtn"), sr = $(".sr");
  const chipIcon = $(".chip svg"), chipName = $(".chipname");

  // ---------- where the cat sits ----------
  // pos is the cat's center on screen, saved as a fraction of the window so it
  // stays in the same corner when the window changes size. The bar unrolls
  // toward the side with more room, and the panel opens below the bar when the
  // cat is near the top.
  const CAT_R = 40;                       // the cat's center is 40px in from its corner of the box
  let pos = null, mirror = false, below = false, barW = 440, hostW = 440 + CAT_W, geom = null;
  const cat = R.build($("svg.anim"));
  function defaultPos() { return { fx: (window.innerWidth - 16 - CAT_R) / window.innerWidth, fy: (window.innerHeight - 16 - CAT_R) / window.innerHeight }; }
  function layout() {
    pos = pos || defaultPos();
    const W = window.innerWidth, H = window.innerHeight;
    const cx = Math.min(W - CAT_R, Math.max(CAT_R, pos.fx * W));
    const cy = Math.min(H - CAT_R, Math.max(70, pos.fy * H));
    mirror = cx < W / 2;
    const room = mirror ? W - (cx - CAT_R) - CAT_W - 16 : cx + CAT_R - CAT_W - 16;
    barW = Math.max(240, Math.min(440, room));
    hostW = barW + CAT_W;
    const panelRoomAbove = cy - CAT_R - BAR_H - 24, panelRoomBelow = H - cy - 24;
    below = panelRoomAbove < 320 && panelRoomBelow > panelRoomAbove;
    const panelH = Math.max(200, Math.min(460, (below ? panelRoomBelow : panelRoomAbove)));
    host.style.width = hostW + "px";
    host.style.left = (mirror ? cx - CAT_R : cx + CAT_R - hostW) + "px";
    host.style.top = (cy + CAT_R - SIZE.h) + "px";
    $("svg.anim").setAttribute("viewBox", `0 0 ${hostW} ${SIZE.h}`);
    wrap.classList.toggle("mirror", mirror);
    wrap.classList.toggle("below", below);
    wrap.style.setProperty("--bar-w", barW + "px");
    wrap.style.setProperty("--panel-h", panelH + "px");
    geom = R.geometry(hostW, SIZE.h);
  }
  layout();
  window.addEventListener("resize", () => { layout(); paint(); });
  try {
    chrome.storage.local.get("cat_pos").then((r) => { if (r && r.cat_pos) { pos = r.cat_pos; layout(); paint(); } });
  } catch (e) {}

  // ---------- theme: follow the person's Claude colors ----------
  CatExt.theme.watch((t) => {
    for (const k in t.vars) wrap.style.setProperty(k, t.vars[k]);
    wrap.style.setProperty("--c-font", t.font);
  });

  // ---------- the cat timeline ----------
  // p goes from 0 (cat with its ball) to 1 (bar open). The loop only runs while p moves.
  let p = 0, goal = 0, last = 0, running = false, openedOnce = false;
  const clamp = (x) => Math.min(1, Math.max(0, x));
  function paint() {
    const st = cat.render(p, geom);
    wrap.classList.toggle("open", p > 0.1 || goal === 1);
    wrap.classList.toggle("live", p > 0.97);
    // The bar is unrolled up to where the ball is. Once fully open, drop the
    // clip so the / menu above the bar can show.
    const c = st.cut.toFixed(1);
    bar.style.clipPath = st.cut <= 0 ? "none" : mirror ? `inset(-20px ${c}px -20px -20px round 28px)` : `inset(-20px -20px -20px ${c}px round 28px)`;
    // With the yarn used up, the / button takes the ball's spot with a small pop.
    const q = clamp((p - 0.9) / 0.1);
    wrap.style.setProperty("--slash-o", Math.min(1, q * 2));
    wrap.style.setProperty("--slash-s", ((0.6 + 0.4 * q) * (1 + 0.12 * Math.sin(Math.PI * q))).toFixed(3));
    wrap.style.setProperty("--done", clamp((p - 0.92) / 0.08));
  }
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    // The first open plays the whole show; later ones are quicker; closing is quickest.
    const dur = goal > p ? (openedOnce ? R.DURATION.reopen : R.DURATION.open) : R.DURATION.close;
    p = goal > p ? Math.min(goal, p + dt / dur) : Math.max(goal, p - dt / dur);
    paint();
    if (p === 1) openedOnce = true;
    if (p !== goal) requestAnimationFrame(frame);
    else running = false;
  }
  function go(t) {
    goal = t;
    if (!running && p !== goal) {
      running = true;
      requestAnimationFrame((now) => { last = now; frame(now); });
    }
  }
  paint();

  // ---------- opening and closing ----------
  // The bar stays open while it is in use: focused, holding text, showing the
  // menu, or running a side chat. Otherwise it folds back when the pointer leaves.
  let inside = false, leaveTimer = null, session = null, busy = false, mode = null, dragging = false;
  const inUse = () => !!session || !!mode || input.value.trim() !== "" || menu.classList.contains("show") || (root.activeElement && root.activeElement !== catHit);
  // A short pause before opening, so a mouse just passing over doesn't set it off.
  let openTimer = null;
  function open() { clearTimeout(leaveTimer); clearTimeout(openTimer); openTimer = setTimeout(() => go(1), goal === 1 ? 0 : 120); }
  function maybeClose(delay) {
    clearTimeout(leaveTimer);
    if (dragging) return;
    leaveTimer = setTimeout(() => { if (!inside && !inUse()) closeAll(); }, delay);
  }
  catHit.addEventListener("mouseenter", () => { inside = true; open(); });
  catHit.addEventListener("mouseleave", () => { inside = false; clearTimeout(openTimer); maybeClose(700); });
  composer.addEventListener("mouseenter", () => { inside = true; clearTimeout(leaveTimer); });
  composer.addEventListener("mouseleave", () => { inside = false; maybeClose(900); });
  catHit.addEventListener("click", () => {
    if (justDragged) { justDragged = false; return; }
    clearTimeout(openTimer); go(1);
    setTimeout(() => input.focus(), (openedOnce ? R.DURATION.reopen : R.DURATION.open) * 1000 * (1 - p));
  });
  input.addEventListener("blur", () => maybeClose(900));
  // Keep the page's highlighted text alive when the cat or a command is pressed.
  [catHit, ballBtn, menu].forEach((b) => b.addEventListener("mousedown", (e) => e.preventDefault()));

  function closeAll() {
    hideMenu();
    closePanel();
    input.value = "";
    autosize();
    input.blur();
    go(0);
  }
  closeX.addEventListener("click", closeAll);

  // ---------- the / menu ----------
  let shown = [], active = 0;
  function showMenu(filter) {
    filter = (filter || "").toLowerCase();
    shown = COMMANDS.filter((c) => c.name.startsWith(filter));
    if (!shown.length) menu.innerHTML = '<div class="empty">No command called /' + filter.replace(/[<>&"]/g, "") + "</div>";
    else {
      menu.innerHTML = shown.map((c, i) => `
        <button type="button" class="item" role="option" data-i="${i}"${c.enabled ? "" : ' aria-disabled="true"'}>
          <svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[c.name]}</svg>
          <span class="t"><span class="n">/${c.name}</span><span class="h">${c.hint}</span></span>
          ${c.enabled ? "" : '<span class="soon">soon</span>'}
        </button>`).join("");
      menu.querySelectorAll(".item").forEach((b) => {
        b.addEventListener("mouseenter", () => setActive(+b.dataset.i));
        b.addEventListener("click", () => pick(+b.dataset.i));
      });
    }
    const firstOn = shown.findIndex((c) => c.enabled);
    setActive(firstOn < 0 ? 0 : firstOn);
    menu.classList.add("show");
    ballBtn.setAttribute("aria-expanded", "true");
  }
  function hideMenu() {
    menu.classList.remove("show");
    ballBtn.setAttribute("aria-expanded", "false");
  }
  function setActive(i) {
    active = i;
    menu.querySelectorAll(".item").forEach((b, j) => {
      b.classList.toggle("on", j === i);
      b.setAttribute("aria-selected", j === i ? "true" : "false");
    });
  }
  function move(step) {
    if (!shown.length) return;
    let i = active;
    for (let n = 0; n < shown.length; n++) {
      i = (i + step + shown.length) % shown.length;
      if (shown[i].enabled) return setActive(i);
    }
  }
  function pick(i) {
    const c = shown[i];
    if (!c) return;
    if (!c.enabled) { sr.textContent = "/" + c.name + " is coming soon."; return; }
    hideMenu();
    input.value = "";
    autosize();
    input.focus();
    if (c.name === "branch") startBranch();
    else if (c.name === "share") startShare();
    else if (c.name === "clone") startClone();
  }
  ballBtn.addEventListener("click", () => {
    if (menu.classList.contains("show")) hideMenu();
    else showMenu("");
    input.focus();
  });

  // ---------- the side chat ----------
  function add(cls, text) {
    const el = document.createElement("div");
    el.className = cls;
    if (text !== undefined) el.textContent = text;
    body.appendChild(el);
    body.scrollTop = body.scrollHeight;
    return el;
  }

  // The panel shows one thing at a time: a branch, a share, or a clone.
  function openPanel(m, subText) {
    if (mode && mode !== m) closePanel();
    mode = m;
    chipIcon.innerHTML = ICONS[m];
    chipName.textContent = m;
    endBtn.textContent = m === "branch" ? "End" : "Close";
    sub.textContent = subText || "";
    body.textContent = "";
    panel.classList.add("show");
  }

  async function startBranch() {
    if (session) return session;
    openPanel("branch", "Reading the main chat");
    const dots = add("dots");
    dots.innerHTML = "<i></i><i></i><i></i>";
    let s;
    try {
      s = await CatExt.brain.startBranch();
    } catch (err) {
      body.textContent = "";
      sub.textContent = "";
      add("err", "Could not read the main chat: " + (err.message || err));
      return null;
    }
    session = s;
    body.textContent = "";
    const n = s.main.messages.length;
    if (s.main.source === "api") sub.textContent = "knows the main chat, " + n + " messages";
    else if (s.main.source === "page") sub.textContent = "read the main chat from the page";
    else sub.textContent = "no chat open to read";
    if (s.branch.highlight) {
      add("label", "Highlighted in the main chat");
      add("quote", s.branch.highlight);
    }
    if (s.main.source === "page") add("note", "Could not load the chat data (" + s.main.error + "), so this side chat sees the visible page text instead.");
    return s;
  }

  function closePanel() {
    const old = session;
    session = null;
    busy = false;
    mode = null;
    if (old) CatExt.brain.close(old);
    panel.classList.remove("show");
    body.textContent = "";
    updateSend();
  }
  endBtn.addEventListener("click", () => { closePanel(); input.focus(); });

  // ---------- share: a memory pack for a teammate ----------
  async function startShare() {
    openPanel("share", "Writing a memory pack from this chat");
    add("note", "Claude is summing up this chat in a hidden side chat. Your main chat stays as it is.");
    const preview = add("ans");
    preview.innerHTML = '<span class="dots"><i></i><i></i><i></i></span>';
    let pending = "", queued = false;
    const draw = () => { queued = false; if (mode === "share") { preview.innerHTML = CatExt.markdown.render(pending); body.scrollTop = body.scrollHeight; } };
    let pack;
    try {
      pack = await CatExt.brain.makePack((t) => { pending = t; if (!queued) { queued = true; requestAnimationFrame(draw); } });
    } catch (err) {
      if (mode !== "share") return;
      body.textContent = "";
      add("err", "Could not make the memory pack: " + (err.message || err));
      return;
    }
    if (mode !== "share") return;
    showPackEditor(CatExt.brain.wrapPack(pack.title, pack.body));
  }

  function showPackEditor(text) {
    sub.textContent = "Read it, edit anything, then copy it";
    body.textContent = "";
    add("label", "Memory pack (you can edit it)");
    const box = document.createElement("textarea");
    box.className = "pack";
    box.id = "cat-pack";
    box.setAttribute("aria-label", "Memory pack, editable");
    box.value = text;
    body.appendChild(box);
    const warn = add("warn");
    const actions = add("actions");
    const copy = document.createElement("button");
    copy.type = "button"; copy.className = "primary"; copy.textContent = "Copy pack";
    const how = document.createElement("span");
    how.className = "note"; how.textContent = "Your teammate pastes it into their cat with /clone.";
    actions.append(copy, how);
    // Flag lines that look like keys or passwords, and update as they edit.
    function check() {
      const hits = CatExt.brain.findSecrets(box.value);
      warn.style.display = hits.length ? "" : "none";
      warn.innerHTML = hits.length ? "<b>Check before sending.</b> These lines look private:<ul>" +
        hits.slice(0, 6).map((h) => "<li>Line " + h.line + " looks like " + h.what + "</li>").join("") + "</ul>" : "";
    }
    box.addEventListener("input", check);
    check();
    copy.addEventListener("click", async () => {
      let ok = false;
      try { await navigator.clipboard.writeText(box.value); ok = true; } catch (e) {
        box.select();
        try { ok = document.execCommand("copy"); } catch (e2) {}
      }
      copy.textContent = ok ? "Copied" : "Select the text and copy it";
      sr.textContent = ok ? "Memory pack copied." : "Could not copy automatically.";
      setTimeout(() => { copy.textContent = "Copy pack"; }, 1800);
    });
    body.scrollTop = 0;
  }

  // ---------- clone: start a chat from a teammate's pack ----------
  function startClone() {
    openPanel("clone", "Start a chat from a teammate's memory pack");
    add("label", "Paste the memory pack here");
    const box = document.createElement("textarea");
    box.className = "pack";
    box.id = "cat-clone";
    box.setAttribute("aria-label", "Paste a memory pack");
    box.placeholder = "===== CAT MEMORY PACK v1 =====";
    body.appendChild(box);
    const actions = add("actions");
    const go2 = document.createElement("button");
    go2.type = "button"; go2.className = "primary"; go2.textContent = "Start the chat"; go2.disabled = true;
    const how = document.createElement("span");
    how.className = "note"; how.textContent = "It opens as a new chat in your account.";
    actions.append(go2, how);
    const status = add("note");
    box.addEventListener("input", () => { go2.disabled = box.value.trim().length < 40; });
    go2.addEventListener("click", async () => {
      go2.disabled = true; box.readOnly = true;
      status.className = "note";
      status.textContent = "Loading the pack into a new chat...";
      try {
        const id = await CatExt.brain.clonePack(box.value);
        status.textContent = "Done. Opening the new chat.";
        location.assign("/chat/" + id);
      } catch (err) {
        status.className = "err";
        status.textContent = String(err.message || err);
        go2.disabled = false; box.readOnly = false;
      }
    });
    setTimeout(() => box.focus(), 50);
  }

  async function submit() {
    const q = input.value.trim();
    if (!q || busy) return;
    if (q.startsWith("/")) {
      // A typed command, like "/branch" + Enter.
      if (menu.classList.contains("show") && shown.length) pick(active);
      return;
    }
    if (mode && mode !== "branch") closePanel();
    busy = true;
    updateSend();
    input.value = "";
    autosize();
    const s = session || (await startBranch());
    if (!s) { busy = false; updateSend(); return; }
    add("you", q);
    const out = add("ans");
    out.innerHTML = '<span class="dots"><i></i><i></i><i></i></span>';
    let pending = "", queued = false;
    const draw = () => { queued = false; out.innerHTML = CatExt.markdown.render(pending); body.scrollTop = body.scrollHeight; };
    try {
      await CatExt.brain.send(s, q, (text) => {
        pending = text;
        if (!queued) { queued = true; requestAnimationFrame(draw); }
      });
    } catch (err) {
      out.className = "err";
      out.textContent = String(err.message || err);
    }
    busy = false;
    updateSend();
    input.focus();
  }

  // ---------- typing ----------
  function autosize() {
    input.style.height = "44px";
    input.style.height = Math.min(input.scrollHeight, 150) + "px";
  }
  function updateSend() {
    const v = input.value.trim();
    sendBtn.disabled = busy || !v || (v.startsWith("/") && !menu.classList.contains("show"));
  }
  input.addEventListener("input", () => {
    autosize();
    const m = input.value.match(/^\/(\w*)$/);
    if (m) showMenu(m[1]);
    else hideMenu();
    updateSend();
  });
  // Enter sends. Tab+Enter (hold Tab, press Enter) or Shift+Enter makes a new line.
  // While the / menu is open, the arrow keys move and Enter or Tab picks.
  let tabHeld = false;
  input.addEventListener("keydown", (e) => {
    const menuOpen = menu.classList.contains("show");
    if (menuOpen && (e.key === "ArrowDown" || e.key === "ArrowUp")) { e.preventDefault(); move(e.key === "ArrowDown" ? 1 : -1); return; }
    if (e.key === "Escape") {
      e.preventDefault();
      if (menuOpen) hideMenu();
      else closeAll();
      return;
    }
    if (e.key === "Tab" && !e.shiftKey) {
      e.preventDefault();
      if (menuOpen) { pick(active); return; }
      tabHeld = true;
      return;
    }
    if (e.key === "Enter" && !e.isComposing) {
      if (menuOpen) { e.preventDefault(); pick(active); return; }
      if (e.shiftKey || tabHeld) return;
      e.preventDefault();
      submit();
    }
  });
  input.addEventListener("keyup", (e) => { if (e.key === "Tab") tabHeld = false; });
  input.addEventListener("blur", () => { tabHeld = false; });
  sendBtn.addEventListener("click", submit);
  // Stop the Claude page from reacting to keys typed inside the bar.
  ["keydown", "keyup", "keypress"].forEach((type) => host.addEventListener(type, (e) => e.stopPropagation()));
  // A click anywhere outside the menu closes it.
  root.addEventListener("mousedown", (e) => {
    if (menu.classList.contains("show") && !menu.contains(e.target) && e.target !== ballBtn && !ballBtn.contains(e.target) && e.target !== input) hideMenu();
  });

  // ---------- switching chats ----------
  // claude.ai changes chats without reloading the page, so we watch the address.
  // A side chat belongs to the chat it was opened from, so it ends (and its
  // hidden conversation is deleted) when you move to another chat.
  let lastPath = location.pathname;
  setInterval(() => {
    if (location.pathname === lastPath) return;
    lastPath = location.pathname;
    CatExt.reader.resetSelection();
    if (mode) closePanel();
  }, 500);
  window.addEventListener("pagehide", () => { if (session) CatExt.brain.close(session); });

  // ---------- the cat stays alive: blinking, and watching your mouse ----------
  R.startBlinking((v) => cat.blink(v));
  let mouse = null, lookQueued = false;
  document.addEventListener("mousemove", (e) => {
    const r = host.getBoundingClientRect();
    mouse = [mirror ? r.right - e.clientX : e.clientX - r.left, e.clientY - r.top];
    if (!lookQueued) { lookQueued = true; requestAnimationFrame(() => { lookQueued = false; cat.look(mouse); }); }
  }, { passive: true });
  document.addEventListener("mouseleave", () => cat.look(null));

  // ---------- pick the cat up and move it ----------
  // Press and hold on the cat for a moment to pick it up, then drag. A quick
  // hover or click still opens the bar as usual.
  let holdTimer = null, start = null, grab = null, justDragged = false;
  catHit.addEventListener("pointerdown", (e) => {
    if (e.button !== 0 || p > 0.35) return;
    start = [e.clientX, e.clientY];
    clearTimeout(holdTimer);
    holdTimer = setTimeout(() => {
      dragging = true;
      clearTimeout(openTimer);
      p = 0; goal = 0; paint();
      try { catHit.setPointerCapture(e.pointerId); } catch (err) {}
      const W = window.innerWidth, H = window.innerHeight;
      grab = [start[0] - pos.fx * W, start[1] - pos.fy * H];
      wrap.classList.add("dragging");
      host.style.transformOrigin = (mirror ? CAT_R : hostW - CAT_R) + "px " + (SIZE.h - CAT_R) + "px";
      host.style.transition = "transform .15s ease, filter .15s ease";
      host.style.transform = "translateY(-4px) scale(1.06)";
      host.style.filter = "drop-shadow(0 10px 10px rgba(0,0,0,.22))";
      sr.textContent = "Cat picked up. Move it and let go.";
    }, 260);
  });
  catHit.addEventListener("pointermove", (e) => {
    if (!dragging) {
      if (start && Math.hypot(e.clientX - start[0], e.clientY - start[1]) > 6) { clearTimeout(holdTimer); start = null; }
      return;
    }
    const W = window.innerWidth, H = window.innerHeight;
    pos = { fx: (e.clientX - grab[0]) / W, fy: (e.clientY - grab[1]) / H };
    layout(); paint();
    host.style.transformOrigin = (mirror ? CAT_R : hostW - CAT_R) + "px " + (SIZE.h - CAT_R) + "px";
  });
  function drop() {
    clearTimeout(holdTimer);
    start = null;
    if (!dragging) return;
    dragging = false;
    justDragged = true;
    setTimeout(() => { justDragged = false; }, 400);
    wrap.classList.remove("dragging");
    host.style.transition = "";
    host.style.transform = "";
    host.style.filter = "";
    // It lands with a little squash.
    try {
      host.animate([{ transform: "scale(1.08, 0.9)" }, { transform: "scale(0.97, 1.04)" }, { transform: "none" }], { duration: 260, easing: "ease-out" });
    } catch (err) {}
    try { chrome.storage.local.set({ cat_pos: pos }); } catch (err) {}
    sr.textContent = "Cat dropped.";
  }
  catHit.addEventListener("pointerup", drop);
  catHit.addEventListener("pointercancel", drop);

  document.documentElement.appendChild(host);
})();
