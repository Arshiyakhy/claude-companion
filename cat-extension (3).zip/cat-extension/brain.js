// BRAIN: turns a command into steps, using reader, asker and store.
// No UI code lives here, so a different shell (a desktop cat) could reuse it.
(function () {
  const CatExt = (window.CatExt = window.CatExt || {});
  const MAX_CONTEXT_CHARS = 60000;

  // Pick the message the branch grows from: the last one that contains the
  // highlighted text, or simply the newest message.
  function findAnchor(messages, highlight) {
    if (!messages.length) return null;
    if (highlight) {
      const probe = highlight.slice(0, 80);
      for (let i = messages.length - 1; i >= 0; i--) {
        if (messages[i].text.includes(probe)) return messages[i].id;
      }
    }
    return messages[messages.length - 1].id;
  }

  // The main chat as one block of text, newest part kept if it is very long.
  function transcriptOf(main) {
    let t = main.messages
      .map((m) => (m.role === "you" ? "Human" : m.role === "claude" ? "Assistant" : "Page text") + ":\n" + m.text)
      .join("\n\n");
    if (t.length > MAX_CONTEXT_CHARS) t = "[earlier part left out]\n" + t.slice(-MAX_CONTEXT_CHARS);
    return t;
  }

  function buildFirstPrompt(session, question) {
    const transcript = transcriptOf(session.main);
    const parts = [
      "This is a quick side question about another conversation, shown below. " +
        "Answer only the side question. Keep it short and focused, and do not continue the main task.",
      "<main_conversation>\n" + (transcript || "(empty)") + "\n</main_conversation>",
    ];
    if (session.branch.highlight) {
      parts.push("<highlighted_part>\n" + session.branch.highlight + "\n</highlighted_part>");
    }
    parts.push("Side question: " + question);
    return parts.join("\n\n");
  }

  // branch: read the main chat and the highlight, and create the branch record.
  async function startBranch() {
    const highlight = CatExt.reader.getHighlight();
    const main = await CatExt.reader.getMainChat();
    const branch = {
      id: CatExt.store.uid(),
      mainChatId: main.id,
      anchor: findAnchor(main.messages, highlight),
      highlight,
      messages: [],
      createdAt: new Date().toISOString(),
    };
    return { branch, main, org: null, sideConvId: null, parent: null };
  }

  // Send one question in the side chat. onDelta gets the answer as it grows.
  async function send(session, question, onDelta) {
    if (!session.org) session.org = await CatExt.reader.getOrgId();
    const first = !session.sideConvId;
    if (first) session.sideConvId = await CatExt.asker.createConversation(session.org);

    const prompt = first ? buildFirstPrompt(session, question) : question;
    const result = await CatExt.asker.ask({
      org: session.org,
      convId: session.sideConvId,
      prompt,
      parent: session.parent,
      onDelta,
    });
    session.parent = result.messageUuid;

    session.branch.messages.push({ role: "you", text: question });
    session.branch.messages.push({ role: "claude", text: result.text });
    await CatExt.store.save(session.branch);
    return result.text;
  }

  // Closing removes the hidden conversation from your Claude history.
  // The side chat itself stays saved in the extension's own store.
  async function close(session) {
    if (session && session.org && session.sideConvId) {
      await CatExt.asker.deleteConversation(session.org, session.sideConvId);
      session.sideConvId = null;
    }
  }

  // ---------- share: the memory pack ----------
  // A memory pack is a handoff: what a teammate's Claude needs to know to keep
  // working on the project, without reading the whole chat.
  const PACK_START = "===== CAT MEMORY PACK v1 =====";
  const PACK_END = "===== END OF PACK =====";

  function packPrompt(main) {
    return [
      "Write a memory pack from the conversation below. A memory pack is a handoff note: it lets a teammate's Claude " +
        "pick up this project and keep working without reading the conversation.",
      "Write it in Markdown with exactly these sections:\n" +
        "## Project (what it is and why, 1 to 3 sentences)\n" +
        "## Where things stand\n" +
        "## Decisions made (each with the reason)\n" +
        "## Key details (names, files, commands, numbers, and short code only where it matters)\n" +
        "## Open questions\n" +
        "## Next steps",
      "Only include what the conversation supports. Be specific. No introduction or sign-off. Keep it under 600 words. " +
        "Leave out passwords, API keys, tokens and private contact details; write [removed] in their place.",
      "<conversation>\n" + (transcriptOf(main) || "(empty)") + "\n</conversation>",
    ].join("\n\n");
  }

  // Writes a memory pack from the current chat in a hidden conversation, which
  // is deleted afterward. onDelta gets the pack as it is written.
  async function makePack(onDelta) {
    const main = await CatExt.reader.getMainChat();
    if (!main.messages.length) throw new Error("There is no chat open to share.");
    const org = await CatExt.reader.getOrgId();
    const convId = await CatExt.asker.createConversation(org);
    try {
      const r = await CatExt.asker.ask({ org, convId, prompt: packPrompt(main), onDelta });
      return { body: r.text.trim(), title: main.title || "a project chat" };
    } finally {
      CatExt.asker.deleteConversation(org, convId);
    }
  }

  // The text that gets sent to a teammate: the pack between two marker lines.
  function wrapPack(title, body) {
    const date = new Date().toISOString().slice(0, 10);
    return [PACK_START, "From: " + title, "Shared: " + date, "", body.trim(), PACK_END].join("\n");
  }

  // Reads a pasted pack. Works with or without the marker lines.
  function readPack(text) {
    let t = text.trim();
    const a = t.indexOf(PACK_START), b = t.indexOf(PACK_END);
    if (a >= 0) t = t.slice(a + PACK_START.length, b > a ? b : undefined).trim();
    const m = t.match(/^From:\s*(.+)$/m);
    return { title: m ? m[1].trim() : "a teammate's chat", body: t };
  }

  // Lines that look like secrets, so the person can check them before sending.
  const SECRET_PATTERNS = [
    [/sk-[A-Za-z0-9_-]{16,}/, "an API key"],
    [/(ghp|gho|github_pat)_[A-Za-z0-9_]{20,}/, "a GitHub token"],
    [/AKIA[0-9A-Z]{16}/, "an AWS key"],
    [/-----BEGIN [A-Z ]*PRIVATE KEY-----/, "a private key"],
    [/\b(api[_ -]?key|secret|password|passwd|token)\b\s*[:=]\s*\S{6,}/i, "a password or key"],
    [/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/, "a login token"],
  ];
  function findSecrets(text) {
    const hits = [];
    text.split("\n").forEach((line, i) => {
      for (const [re, what] of SECRET_PATTERNS) {
        if (re.test(line)) { hits.push({ line: i + 1, what }); break; }
      }
    });
    return hits;
  }

  // ---------- clone: start a chat from a teammate's pack ----------
  // Creates a normal (kept) chat in this account whose first message is the
  // pack, so this Claude starts out caught up. Returns the new chat's id.
  async function clonePack(text, onDelta) {
    const pack = readPack(text);
    if (pack.body.length < 40) throw new Error("That doesn't look like a memory pack. Paste the whole thing your teammate sent.");
    const org = await CatExt.reader.getOrgId();
    const convId = await CatExt.asker.createConversation(org, "From teammate: " + pack.title.slice(0, 60));
    const prompt =
      "My teammate shared this memory pack from their Claude chat about our project. Read it, then reply with a short " +
      "summary of where things stand and ask what I'd like to work on next.\n\n" + text.trim();
    await CatExt.asker.ask({ org, convId, prompt, onDelta });
    return convId;
  }

  CatExt.brain = { startBranch, send, close, makePack, wrapPack, readPack, findSecrets, clonePack };
})();
