// BRAIN: what each command does, step by step, using site, ai and store.
// No UI code lives here.
(function () {
  const CatExt = (window.CatExt = window.CatExt || {});
  const MAX_CONTEXT_CHARS = 60000;
  const site = () => CatExt.site;

  // The main chat as one block of text, newest part kept if it is very long.
  function transcriptOf(main) {
    let t = main.messages
      .map((m) => (m.role === "you" ? "Human" : m.role === "ai" ? "Assistant" : "Page text") + ":\n" + m.text)
      .join("\n\n");
    if (t.length > MAX_CONTEXT_CHARS) t = "[earlier part left out]\n" + t.slice(-MAX_CONTEXT_CHARS);
    return t;
  }
  const sideTranscript = (msgs) => msgs.map((m) => (m.role === "you" ? "Me" : "You") + ": " + m.text).join("\n\n");

  function firstPrompt(session, question) {
    const parts = [
      "This is a quick side question about another conversation, shown below. " +
        "Answer only the side question. Keep it short and focused, and do not continue the main task.",
      "<main_conversation>\n" + (transcriptOf(session.main) || "(empty)") + "\n</main_conversation>",
    ];
    if (session.branch.highlight) parts.push("<highlighted_part>\n" + session.branch.highlight + "\n</highlighted_part>");
    // A side chat reopened from /log: catch the new session up on it.
    if (session.branch.messages.length) parts.push("<side_chat_so_far>\n" + sideTranscript(session.branch.messages) + "\n</side_chat_so_far>");
    parts.push("Side question: " + question);
    return parts.join("\n\n");
  }

  // ---------- branch ----------
  // Pass an old branch (from /log) to pick it up again.
  async function startBranch(old) {
    const main = await site().read();
    const branch = old || {
      id: CatExt.store.uid(),
      site: site().id,
      chatKey: site().chatKey(),
      chatTitle: main.title || "",
      highlight: site().getHighlight(),
      messages: [],
      createdAt: new Date().toISOString(),
    };
    return { branch, main, ai: null };
  }

  async function send(session, question, onDelta) {
    const first = !session.ai;
    if (first) session.ai = await CatExt.ai.session();
    const text = await session.ai.send(first ? firstPrompt(session, question) : question, onDelta);
    session.branch.messages.push({ role: "you", text: question }, { role: "ai", text });
    session.branch.updatedAt = new Date().toISOString();
    await CatExt.store.save(session.branch);
    return text;
  }

  // Closing ends the hidden chat (on Claude it is deleted from your history).
  // The side chat itself stays saved in the extension, so /log can reopen it.
  function close(session) {
    if (session && session.ai) { session.ai.end(); session.ai = null; }
  }

  // ---------- log: side chats opened from this chat ----------
  async function log() {
    const key = site().chatKey(), id = site().id;
    return (await CatExt.store.all())
      .filter((b) => (b.site || "claude") === id && (b.chatKey || b.mainChatId) === key && b.messages && b.messages.length)
      .sort((a, b) => String(b.updatedAt || b.createdAt).localeCompare(String(a.updatedAt || a.createdAt)));
  }

  // ---------- merge: bring a side chat back into the main chat ----------
  // Writes a short note for the main chat; the shell puts it in the message box.
  function mergeNote(branch, onDelta) {
    const prompt = [
      "Below is a side chat I had about my main conversation. Write a short note I can paste into the main conversation " +
        "so the assistant there knows what I worked out. Write it in first person, as me. Start with \"From a side chat:\". " +
        "Only the useful conclusions, decisions or corrections, in under 100 words. No greeting, no sign-off.",
      branch.highlight ? "<highlighted_part>\n" + branch.highlight + "\n</highlighted_part>" : "",
      "<side_chat>\n" + sideTranscript(branch.messages) + "\n</side_chat>",
    ].filter(Boolean).join("\n\n");
    return CatExt.ai.once(prompt, onDelta).then((t) => t.trim());
  }

  // ---------- share: the memory pack ----------
  const PACK_START = "===== CAT MEMORY PACK v1 =====";
  const PACK_END = "===== END OF PACK =====";

  function packPrompt(main) {
    return [
      "Write a memory pack from the conversation below. A memory pack is a handoff note: it lets someone else's AI " +
        "assistant pick up this project and keep working without reading the conversation.",
      "Write it in Markdown with exactly these sections:\n" +
        "## Project (what it is and why, 1 to 3 sentences)\n" +
        "## Where things stand\n" +
        "## Decisions made (each with the reason)\n" +
        "## Key details (names, files, commands, numbers, and short code only where it matters)\n" +
        "## Open questions\n" +
        "## Next steps",
      "Only include what the conversation supports. Be specific. No introduction or sign-off. Keep it under 600 words. " +
        "Leave out passwords, API keys, tokens and private contact details; write [removed] in their place.",
      "<conversation>\n" + (transcriptOf(main) || "(empty)") + "\n</conversation>",
    ].join("\n\n");
  }

  async function makePack(onDelta) {
    const main = await site().read();
    if (!main.messages.length) throw new Error("There is no chat open to share.");
    const body = (await CatExt.ai.once(packPrompt(main), onDelta)).trim();
    return { body, title: main.title || "a project chat" };
  }

  function wrapPack(title, body) {
    const date = new Date().toISOString().slice(0, 10);
    return [PACK_START, "From: " + title, "Shared: " + date, "", body.trim(), PACK_END].join("\n");
  }

  function readPack(text) {
    let t = text.trim();
    const a = t.indexOf(PACK_START), b = t.indexOf(PACK_END);
    if (a >= 0) t = t.slice(a + PACK_START.length, b > a ? b : undefined).trim();
    const m = t.match(/^From:\s*(.+)$/m);
    return { title: m ? m[1].trim() : "a teammate's chat", body: t };
  }

  const SECRET_PATTERNS = [
    [/sk-[A-Za-z0-9_-]{16,}/, "an API key"],
    [/AIza[0-9A-Za-z_-]{30,}/, "a Google API key"],
    [/(ghp|gho|github_pat)_[A-Za-z0-9_]{20,}/, "a GitHub token"],
    [/AKIA[0-9A-Z]{16}/, "an AWS key"],
    [/-----BEGIN [A-Z ]*PRIVATE KEY-----/, "a private key"],
    [/\b(api[_ -]?key|secret|password|passwd|token)\b\s*[:=]\s*\S{6,}/i, "a password or key"],
    [/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/, "a login token"],
  ];
  function findSecrets(text) {
    const hits = [];
    text.split("\n").forEach((line, i) => {
      for (const [re, what] of SECRET_PATTERNS) if (re.test(line)) { hits.push({ line: i + 1, what }); break; }
    });
    return hits;
  }

  // ---------- clone and fork: start a new chat that already knows the story ----------
  // On Claude the cat creates the chat itself and opens it. On other sites it
  // opens a new chat and puts the message in the box for you to send.
  // Returns the address to go to.
  async function startChatWith(name, message) {
    if (site().account) {
      const id = await CatExt.ai.accountSession().newKeptChat(name, message);
      return "/chat/" + id;
    }
    await site().leaveForNextPage(message);
    return site().newChat || location.pathname;
  }

  async function clonePack(text) {
    const pack = readPack(text);
    if (pack.body.length < 40) throw new Error("That doesn't look like a memory pack. Paste the whole thing your teammate sent.");
    const message =
      "My teammate shared this memory pack from their AI chat about our project. Read it, then reply with a short " +
      "summary of where things stand and ask what I'd like to work on next.\n\n" + text.trim();
    return startChatWith("From teammate: " + pack.title.slice(0, 60), message);
  }

  async function forkWith(packText) {
    const message =
      "This is a memory pack from my previous chat about this project. Read it, then reply with a short summary " +
      "of where things stand and the next step, so we can keep going from here.\n\n" + packText.trim();
    return startChatWith("Fork: " + readPack(packText).title.slice(0, 60), message);
  }

  CatExt.brain = { startBranch, send, close, log, mergeNote, makePack, wrapPack, readPack, findSecrets, clonePack, forkWith };
})();
